﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Threading;
using System.IO;
using System.Data.SqlClient;
using System.Xml.Serialization; 

namespace Sample
{
    public partial class frmSample : Form
    {
        private delegate void AsyncAction();
        private DataManager dbMgr = new DataManager();
        private bool isContinue = true; 

        public frmSample()
        {
            InitializeComponent();
        }

        private void frmSample_Load(object sender, EventArgs e)
        {
            txtInput.AllowDrop = true; 
            txtInput.DragEnter += new System.Windows.Forms.DragEventHandler(txtBox_DragEnter); 
            txtInput.DragDrop += new System.Windows.Forms.DragEventHandler(txtBox_DragDrop);
        }

        private void txtBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void txtBox_DragDrop(object sender, DragEventArgs e)
        {
            foreach (string fileName in (string[])e.Data.GetData(DataFormats.FileDrop))
            {
                ((TextBox)sender).Text += fileName; 
            }
        }

        private void btnAction_Click(object sender, EventArgs e)
        { 
            if (isContinue)
            {
                btnAction.Enabled = false;
                AsyncAction importer = new AsyncAction(ImportRecords);
                IAsyncResult asyncInput = importer.BeginInvoke(null, null);
                importer.EndInvoke(asyncInput);
            }

            if (isContinue)
            {
                AsyncAction exporter = new AsyncAction(ExportRecords);
                IAsyncResult asyncOutput = exporter.BeginInvoke(null, null);
                exporter.EndInvoke(asyncOutput);
            }

            btnAction.Enabled = true; 
        }

        private void ImportRecords()
        { 
            string inPath = txtInput.Text; 
            StreamReader reader = null;

            try
            {
                reader = new StreamReader(inPath);
                while (isContinue && !reader.EndOfStream)
                {
                    string[] fields = reader.ReadLine().Split('|');
                    UploadToDB(fields); 
                }
            }
            catch (Exception ex)
            {
                isContinue = (MessageBox.Show(ex.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
            }
            finally
            {
                if (reader != null) { reader.Close(); } 
            }
        }

        private bool UploadToDB(string[] fields)
        {
            bool returnValue = false; 

            if (fields.Count() == 3) 
            {
                object checkException = (object)string.Empty;
                returnValue = dbMgr.UpSert(ref checkException, fields[0], fields[1], fields[2]); 
                if (checkException is Exception) 
                {
                    returnValue = false;
                    isContinue = (MessageBox.Show(checkException.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
                } 
            }

            return returnValue; 
        }

        private void ExportRecords()
        {
            string outPath = Directory.GetCurrentDirectory() + @"\Records";
            if (!Directory.Exists(outPath)) 
            {
                try { Directory.CreateDirectory(outPath); }
                catch (Exception ex) 
                { 
                    MessageBox.Show(ex.ToString());
                    return; 
                } 
            }

            object checkException = (object)string.Empty;
            int recordsToSerialize = dbMgr.CheckData(ref checkException);
            if (checkException is Exception) 
            {
                isContinue = (MessageBox.Show(checkException.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
            }

            if (isContinue) 
            { 
                for (int i = 0; i < recordsToSerialize; i++)
                {
                    checkException = (object)string.Empty;
                    DataTable dt = dbMgr.GetRecordSet(ref checkException);
                    if (checkException is Exception) 
                    {
                        isContinue = (MessageBox.Show(checkException.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
                    }

                    if (isContinue) 
                    {
                        if (dt.Columns.Contains("Level1Label") && dt.Columns.Contains("Level2Label") && dt.Columns.Contains("Level3Label"))
                        {
                            int Level1ID = 0; 
                            Level1 l1 = new Level1();
                            foreach (DataRow dr in dt.Rows)
                            {
                                if (string.Compare(string.Empty, l1.Label, true) == 0)
                                {
                                    Level1ID = (int)dr["Level1ID"]; 
                                    l1.Label = dr["Level1Label"].ToString();
                                }

                                string l2Label = dr["Level2Label"].ToString();
                                Level2 l2 = l1.listLevel2.Find(l => string.Compare(l2Label, l.Label, true) == 0);
                                if (l2 == null)
                                {
                                    l1.listLevel2.Add(new Level2(l2Label));
                                }
                                else
                                {
                                    string l3Label = dr["Level3Label"].ToString();
                                    Level3 l3 = l2.listLevel3.Find(l => string.Compare(l3Label, l.Label, true) == 0);
                                    if (l3 == null)
                                    {
                                        l2.listLevel3.Add(new Level3(l3Label));
                                    }
                                }
                            }

                            WriteToDisk(outPath, l1);
                            if (isContinue)
                            {
                                checkException = (object)string.Empty;
                                dbMgr.MarkSerialized(ref checkException, Level1ID);
                                if (checkException is Exception)
                                {
                                    isContinue = (MessageBox.Show(checkException.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
                                }
                            }
                            
                        }
                    }
                }
            }
        }

        private bool WriteToDisk(string folderPath, Level1 l1)
        {
            bool returnValue = false; 

            string filePath = folderPath + @"\" + l1.Label + ".xml";
            if (!File.Exists(filePath)) 
            {
                StreamWriter writer = null; 

                try
                {
                    writer = new StreamWriter(filePath, false); 
                    XmlSerializer xSerializer = new XmlSerializer(typeof(Level1));
                    xSerializer.Serialize(writer, l1);
                    returnValue = true; 
                }
                catch (Exception ex)
                {
                    isContinue = (MessageBox.Show(ex.ToString(), "Click Yes To Continue", MessageBoxButtons.YesNo) == DialogResult.Yes);
                }
                finally
                {
                    if (writer != null) { writer.Close(); } 
                }
            }

            return returnValue; 
        }
    }

    public class DataManager 
    {
        string connectionString = @"Server=(local)\SQLExpress;Database=Sample;Trusted_Connection=True;";
        SqlCommand command = new SqlCommand();
        SqlDataAdapter adaptor = new SqlDataAdapter();

        public DataManager()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            command.Connection = conn;
        }

        public bool UpSert(ref object checkException, string level1, string level2, string level3) 
        {
            bool returnValue = false;

            try
            {
                command.Connection.Open(); 

                command.CommandType = CommandType.Text;
                command.CommandText =
                    "SELECT @ID = ID FROM dbo.Level1 WITH(NOLOCK) WHERE Label = @Label; "
                    + "IF (@ID IS NULL OR @ID = 0) "
                    + "BEGIN "
                    + " INSERT INTO dbo.Level1 (Label) SELECT @Label "
                    + " SELECT @ID = SCOPE_IDENTITY() "
                    + "END ";
                SqlParameter[] sp = new SqlParameter[2];
                sp[0] = command.Parameters.AddWithValue("@ID", (object)0);
                command.Parameters["@ID"].Direction = ParameterDirection.Output;
                sp[1] = command.Parameters.AddWithValue("@Label", (object)level1);

                command.ExecuteNonQuery();
                int level1ID = (int)command.Parameters["@ID"].Value;
                command.Parameters.Clear();

                command.CommandText =
                    "SELECT @ID = ID FROM dbo.Level2 WITH(NOLOCK) WHERE Label = @Label AND Level1ID = @ParentID; "
                    + "IF (@ID IS NULL OR @ID = 0) "
                    + "BEGIN "
                    + " INSERT INTO dbo.Level2 (Label, Level1ID) SELECT @Label, @ParentID "
                    + " SELECT @ID = SCOPE_IDENTITY() "
                    + "END ";
                sp = new SqlParameter[3];
                sp[0] = command.Parameters.AddWithValue("@ID", (object)0);
                command.Parameters["@ID"].Direction = ParameterDirection.Output;
                sp[1] = command.Parameters.AddWithValue("@Label", (object)level2);
                sp[2] = command.Parameters.AddWithValue("@ParentID", (object)level1ID);

                command.ExecuteNonQuery();
                int level2ID = (int)command.Parameters["@ID"].Value;
                command.Parameters.Clear();

                command.CommandText =
                    "SELECT @ID = ID FROM dbo.Level3 WITH(NOLOCK) WHERE Label = @Label AND Level2ID = @ParentID; "
                    + "IF (@ID IS NULL OR @ID = 0) "
                    + "BEGIN "
                    + " INSERT INTO dbo.Level3 (Label, Level2ID) SELECT @Label, @ParentID "
                    + "END ";
                command.Parameters.Clear();
                sp = new SqlParameter[3];
                sp[0] = command.Parameters.AddWithValue("@ID", (object)0);
                sp[1] = command.Parameters.AddWithValue("@Label", (object)level3);
                sp[2] = command.Parameters.AddWithValue("@ParentID", (object)level2ID);

                command.ExecuteNonQuery();
                command.Parameters.Clear();
                returnValue = true;
            }
            catch (Exception ex)
            {
                checkException = ex;
            }
            finally
            {
                command.Connection.Close(); 
            }

            return returnValue;
        }

        public int CheckData(ref object checkException)
        {
            int returnValue = -1;

            DataSet ds = new DataSet(); 
            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT COUNT(1) 'Records' FROM dbo.Level1 WHERE IsSerialized = 0 ";
            command.Parameters.Clear();

            try
            {
                adaptor.SelectCommand = command;
                adaptor.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    if (dt.Rows.Count > 0 && dt.Columns.Contains("Records"))
                    {
                        returnValue = (int)dt.Rows[0]["Records"]; 
                    }
                }
            }
            catch (Exception ex)
            {
                checkException = ex;
            }

            return returnValue; 
        }

        public DataTable GetRecordSet(ref object checkException)
        {
            DataTable returnValue = new DataTable(); 

            DataSet ds = new DataSet();
            command.CommandType = CommandType.Text;
            command.CommandText =
                "DECLARE @ID INT "
                + "SELECT @ID = MIN(ID) FROM dbo.Level1 WHERE IsSerialized = 0 "
                + "SELECT uno.ID 'Level1ID', uno.Label 'Level1Label' "
                + "	, dos.ID 'Level2ID', dos.Label 'Level2Label' "
                + "	, tres.ID 'Level3ID', tres.Label 'Level3Label' "
                + "FROM dbo.Level1 uno WITH(NOLOCK) "
                + "INNER JOIN dbo.Level2 dos WITH(NOLOCK) ON uno.ID = dos.Level1ID "
                + "INNER JOIN dbo.Level3 tres WITH(NOLOCK) ON dos.ID = tres.Level2ID "
                + "WHERE uno.ID = @ID ";
            command.Parameters.Clear();

            try
            {
                adaptor.SelectCommand = command;
                adaptor.Fill(ds); 
                if (ds.Tables.Count > 0)
                {
                    returnValue = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                checkException = ex;
            }

            return returnValue;
        }

        public bool MarkSerialized(ref object checkException, int level1ID)
        {
            bool returnValue = false;

            try
            {
                command.Connection.Open();

                command.CommandType = CommandType.Text;
                command.CommandText =
                    "UPDATE dbo.Level1 SET IsSerialized = 1 WHERE ID = @ID ";
                command.Parameters.Clear();
                SqlParameter[] sp = new SqlParameter[1];
                sp[0] = command.Parameters.AddWithValue("@ID", (object)level1ID);

                command.ExecuteNonQuery();
                returnValue = true; 
            }
            catch (Exception ex)
            {
                checkException = ex;
            }
            finally
            {
                command.Connection.Close();
            }

            return returnValue;
        }
    }

    [Serializable]
    public class Level1
    {
        public string Label;
        public List<Level2> listLevel2 = new List<Level2>(); 
        public Level1() { Label = string.Empty; }
        public Level1(string inValue) { Label = inValue; }
    }

    [Serializable]
    public class Level2
    {
        public string Label;
        public List<Level3> listLevel3 = new List<Level3>(); 
        public Level2() { Label = string.Empty; }
        public Level2(string inValue) { Label = inValue; }
    }

    [Serializable]
    public class Level3
    {
        public string Label;
        public Level3() { Label = string.Empty; }
        public Level3(string inValue) { Label = inValue; }
    }
}
