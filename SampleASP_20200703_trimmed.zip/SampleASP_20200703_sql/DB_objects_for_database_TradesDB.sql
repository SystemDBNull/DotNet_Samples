USE [TradesDB]
GO
/****** Object:  Table [dbo].[Accounts]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Accounts](
	[AccountID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[AccountDisplay] [nvarchar](50) NOT NULL,
	[Cash] [decimal](18, 4) NOT NULL,
 CONSTRAINT [PK_Accounts] PRIMARY KEY NONCLUSTERED 
(
	[AccountID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [CIX_Accounts]    Script Date: 7/12/2020 6:48:33 PM ******/
CREATE UNIQUE CLUSTERED INDEX [CIX_Accounts] ON [dbo].[Accounts]
(
	[AccountDisplay] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Symbols]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Symbols](
	[SymbolID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[SymbolDisplay] [nvarchar](25) NOT NULL,
	[SharePrice] [decimal](9, 4) NOT NULL,
 CONSTRAINT [PK_Symbols] PRIMARY KEY NONCLUSTERED 
(
	[SymbolID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [CIX_Symbols]    Script Date: 7/12/2020 6:48:33 PM ******/
CREATE UNIQUE CLUSTERED INDEX [CIX_Symbols] ON [dbo].[Symbols]
(
	[SymbolDisplay] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trades]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trades](
	[TradeID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[AccountID] [uniqueidentifier] NOT NULL,
	[SymbolID] [uniqueidentifier] NOT NULL,
	[ShareCount] [int] NOT NULL,
	[PurchaseDatetime] [datetime] NOT NULL,
	[PurchasePrice] [decimal](9, 4) NOT NULL,
	[SaleDatetime] [datetime] NULL,
	[SalePrice] [decimal](9, 4) NULL,
 CONSTRAINT [PK_Trades] PRIMARY KEY NONCLUSTERED 
(
	[TradeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [CIX_Trades]    Script Date: 7/12/2020 6:48:33 PM ******/
CREATE UNIQUE CLUSTERED INDEX [CIX_Trades] ON [dbo].[Trades]
(
	[PurchaseDatetime] ASC,
	[SymbolID] ASC,
	[AccountID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Accounts] ADD  DEFAULT (newid()) FOR [AccountID]
GO
ALTER TABLE [dbo].[Symbols] ADD  DEFAULT (newid()) FOR [SymbolID]
GO
ALTER TABLE [dbo].[Trades] ADD  DEFAULT (newid()) FOR [TradeID]
GO
ALTER TABLE [dbo].[Trades]  WITH CHECK ADD  CONSTRAINT [FK_TradeAccount] FOREIGN KEY([AccountID])
REFERENCES [dbo].[Accounts] ([AccountID])
GO
ALTER TABLE [dbo].[Trades] CHECK CONSTRAINT [FK_TradeAccount]
GO
ALTER TABLE [dbo].[Trades]  WITH CHECK ADD  CONSTRAINT [FK_TradeSymbol] FOREIGN KEY([SymbolID])
REFERENCES [dbo].[Symbols] ([SymbolID])
GO
ALTER TABLE [dbo].[Trades] CHECK CONSTRAINT [FK_TradeSymbol]
GO
ALTER TABLE [dbo].[Trades]  WITH CHECK ADD  CONSTRAINT [CHK_TradeSale] CHECK  (([SaleDatetime] IS NULL AND [SalePrice] IS NULL OR [SaleDatetime] IS NOT NULL AND [SalePrice] IS NOT NULL))
GO
ALTER TABLE [dbo].[Trades] CHECK CONSTRAINT [CHK_TradeSale]
GO
/****** Object:  StoredProcedure [dbo].[PR_TradesDelete]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[PR_TradesDelete] 
	@TradeID uniqueidentifier

AS 

/*

DECLARE @TradeID uniqueidentifier 
	, @AccountID uniqueidentifier 
	, @SymbolID uniqueidentifier 
	, @ShareCount int 

SELECT TOP 1 @TradeID = TradeID FROM [dbo].[Trades] ORDER BY newid() 
SELECT @AccountID = AccountID, @SymbolID = SymbolID, @ShareCount = ShareCount FROM [dbo].[Trades] WHERE TradeID = @TradeID
SELECT @TradeID, @AccountID, @SymbolID, @ShareCount 

BEGIN TRANSACTION 
	EXEC TradesDB.dbo.PR_TradesDelete 
		@TradeID = @TradeID
	SELECT * FROM [dbo].[Accounts] WHERE AccountID = @AccountID
	SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 
ROLLBACK TRANSACTION 
SELECT @@TRANCOUNT 'TranCount'

SELECT * FROM [dbo].[Accounts] 
SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 

*/

BEGIN 
	--remove an open or closed trade by deleting the trades record 
	DELETE FROM [dbo].[Trades] 
	WHERE TradeID = @TradeID
END 

GO
/****** Object:  StoredProcedure [dbo].[PR_TradesInsert]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[PR_TradesInsert] 
	@AccountID uniqueidentifier
	, @SymbolID uniqueidentifier 
	, @ShareCount int 
	, @PurchaseDatetime datetime 
	, @PurchasePrice decimal (9,4) 

AS 

/*

DECLARE @AccountID uniqueidentifier
	, @SymbolID uniqueidentifier 
	, @ShareCount int 
	, @PurchaseDatetime datetime 
	, @PurchasePrice decimal (9,4) 

SELECT TOP 1 @AccountID = AccountID FROM [dbo].[Accounts] ORDER BY newid() 
SELECT TOP 1 @SymbolID =  SymbolID FROM [dbo].[Symbols] ORDER BY newid() 
SELECT @ShareCount = 1
SELECT @PurchaseDatetime = getdate() 
SELECT @PurchasePrice = 100.00 
--SELECT @AccountID, @SymbolID, @ShareCount, @PurchaseDatetime, @PurchasePrice 

BEGIN TRANSACTION 
	EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @AccountID
		, @SymbolID = @SymbolID
		, @ShareCount = @ShareCount
		, @PurchaseDatetime = @PurchaseDatetime,
		@PurchasePrice = @PurchasePrice
	SELECT * FROM [dbo].[Accounts] WHERE AccountID = @AccountID
	SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 
ROLLBACK TRANSACTION 
SELECT @@TRANCOUNT 'TranCount'

SELECT * FROM [dbo].[Accounts] 
SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 

*/

BEGIN 
	--add a new open trade by inserting a new trades record 
	--theoretically a new closed trade could be added by including SaleDatetime and SalePrice 
	INSERT INTO [dbo].[Trades] (
		AccountID, SymbolID, ShareCount, PurchaseDatetime, PurchasePrice) 
	VALUES (@AccountID, @SymbolID, @ShareCount, @PurchaseDatetime, @PurchasePrice) 
END 


















GO
/****** Object:  StoredProcedure [dbo].[PR_TradesReport]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[PR_TradesReport] 
	@ShowAll bit = 0
	, @TradeID uniqueidentifier = NULL
	, @AccountID uniqueidentifier = NULL
	, @SymbolID uniqueidentifier = NULL

AS 

/*

DECLARE  @AccountID uniqueidentifier 
	, @SymbolID uniqueidentifier 
	, @TradeID uniqueidentifier 

SELECT TOP 1 @TradeID = TradeID FROM [dbo].[Trades] ORDER BY newid() 

--SELECT TOP 1 @AccountID = AccountID FROM [dbo].[Accounts] ORDER BY newid() 
--SELECT TOP 1 @SymbolID = SymbolID FROM [dbo].[Symbols] ORDER BY newid() 

--SELECT TOP 1 @AccountID = AccountID FROM [dbo].[Trades] ORDER BY newid() 
--SELECT TOP 1 @SymbolID = SymbolID FROM [dbo].[Trades] ORDER BY newid() 

--SELECT TOP 1 @AccountID = AccountID, @SymbolID = SymbolID FROM [dbo].[Trades] ORDER BY newid() 

SELECT @AccountID, @SymbolID 

EXEC TradesDB.dbo.PR_TradesReport 
	@ShowAll = 1 
	, @TradeID = @TradeID
	, @AccountID = @AccountID 
	, @SymbolID = @SymbolID 

*/

BEGIN 
	--display trade information with the option of filtering by account and or symbol or by showing only open trades 
	--treat account cash as a symbol and display on a separate line

	--if @TradeID parameter is valued there should also be a SymbolID and AccountID
	--override nulls or passed-in values 
	IF (@TradeID IS NOT NULL) 
	BEGIN 
		SELECT TOP 1 @AccountID = AccountID, @SymbolID = SymbolID FROM [dbo].[Trades] WHERE TradeID = @TradeID 
	END 

	SELECT tr.TradeID  
		, acc.AccountDisplay
		, acc.AccountID
		, sy.SymbolDisplay
		, sy.SymbolID
		, tr.ShareCount
		, tr.PurchaseDatetime
		, tr.PurchasePrice
		, cast(tr.ShareCount * tr.PurchasePrice as int) 'PurchaseValue'
		, tr.SaleDatetime
		, tr.SalePrice
		, sy.SharePrice 'CurrentPrice' 
		, cast(tr.ShareCount * isnull(tr.SalePrice, sy.SharePrice) as int) 'CurrentValue'
		, cast((sy.SharePrice - tr.PurchasePrice) * tr.ShareCount as int) 'Gain-Loss' 
		, cast( ( (sy.SharePrice - tr.PurchasePrice) * 100) / (tr.PurchasePrice) as int) 'PercentGain-Loss' 
	FROM [dbo].[Accounts] acc 
	INNER JOIN [dbo].[Trades] tr ON acc.AccountID = tr.AccountID 
	INNER JOIN [dbo].[Symbols] sy ON tr.SymbolID = sy.SymbolID 
	WHERE (acc.AccountID = isnull(@AccountID, acc.AccountID))	--filter on account when variable is valued
		AND (sy.SymbolID = isnull(@SymbolID, sy.SymbolID))	--filter on symbol when variable is valued
		AND (tr.TradeID = isnull(@TradeID, tr.TradeID))	--filter on trade when variable is valued
		AND (@ShowAll = 1 OR SaleDatetime IS NULL)	--filter on SaleDatetime when variable is false 
	UNION 
	SELECT NULL 'TradeID' 
		, AccountDisplay
		, NULL 'AccountID' 
		, 'Cash' 'SymbolDisplay'
		, NULL 'SymbolID' 
		, Cash 'ShareCount' 
		, NULL 'PurchaseDatetime'
		, 1.0000 'PurchasePrice'
		, cast(Cash * 1.0000 as int) 'PurchaseValue'
		, NULL 'SaleDatetime'
		, NULL 'SalePrice'
		, 1.0000 'CurrentPrice' 
		, cast(Cash * 1.0000 as int) 'CurrentValue'
		, 0 'Gain-Loss'
		, 0 'PercentGain-Loss'
	FROM [dbo].[Accounts] acc 
	WHERE (acc.AccountID = isnull(@AccountID, acc.AccountID))	--filter on account when variable is valued --cash position will always be open 
	ORDER BY SaleDatetime, PurchaseDatetime, AccountDisplay  

END 

GO
/****** Object:  StoredProcedure [dbo].[PR_TradesUpdate]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[PR_TradesUpdate] 
	@TradeID uniqueidentifier
	, @SaleDatetime datetime 
	, @SalePrice decimal (9,4) 

AS 

/*

DECLARE @TradeID uniqueidentifier 
	, @SaleDatetime datetime  
	, @SalePrice decimal (9,4) 
	, @AccountID uniqueidentifier 
	, @SymbolID uniqueidentifier 
	, @ShareCount int 

SELECT TOP 1 @TradeID = TradeID FROM [dbo].[Trades] WHERE SaleDatetime IS NULL ORDER BY newid() 
SELECT @SaleDatetime = getdate() 

SELECT @AccountID = AccountID
	, @SymbolID = SymbolID
	, @ShareCount = ShareCount 
	, @SalePrice = PurchasePrice * 1.1
FROM [dbo].[Trades] WHERE TradeID = @TradeID

SELECT @TradeID, @SaleDatetime, @SalePrice, @AccountID, @SymbolID, @ShareCount 

--BEGIN TRANSACTION 
	EXEC TradesDB.dbo.PR_TradesUpdate 
		@TradeID = @TradeID
		, @SaleDatetime = @SaleDatetime 
		, @SalePrice = @SalePrice 
	SELECT * FROM [dbo].[Accounts] WHERE AccountID = @AccountID
	SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 
--ROLLBACK TRANSACTION 
SELECT @@TRANCOUNT 'TranCount'

SELECT * FROM [dbo].[Accounts] 
SELECT * FROM [dbo].[Trades] ORDER BY PurchaseDatetime DESC 

*/

BEGIN 
	--mark an open trade closed by setting values for both SalePrice and SaleDatetime 
	--the table should reject an update that leaves one value NULL and the other NOT NULL
	UPDATE [dbo].[Trades]  
		SET SaleDatetime = @SaleDatetime
			, SalePrice = @SalePrice
	WHERE TradeID = @TradeID
END 


GO
/****** Object:  Trigger [dbo].[TradesDelete]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TradesDelete] ON [dbo].[Trades] 
FOR DELETE
AS

/*
update account cash values as trades are deleted 
deleted records may or may not have SalePrice values 
app users should correct trades records by deleting the existing record and re-entering with correct values 
*/

BEGIN 
	SET NOCOUNT ON
	DECLARE @SalePrice int 
	
	--reverse the effect of existing trade
	SELECT @SalePrice = isnull([SalePrice], 0) FROM Deleted
	UPDATE [dbo].[Accounts] 
		SET [Cash] = [Cash] 
				+ (d.[PurchasePrice] * d.[ShareCount])
				- (@SalePrice * d.[ShareCount])
	FROM Deleted d 
	WHERE [dbo].[Accounts].[AccountID] = d.[AccountID]  
END 




GO
ALTER TABLE [dbo].[Trades] ENABLE TRIGGER [TradesDelete]
GO
/****** Object:  Trigger [dbo].[TradesInsert]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TradesInsert] ON [dbo].[Trades] 
FOR INSERT
AS

/*
update account cash values as trades are inserted 
the app should only insert trades with null SalePrice but include a check on it in case of inserts from other sources 
*/

BEGIN 
	SET NOCOUNT ON
	DECLARE @SalePrice int 
	
	--apply the new trade value
	SELECT @SalePrice = isnull([SalePrice], 0) FROM Inserted
	UPDATE [dbo].[Accounts] 
		SET [Cash] = [Cash] 
				- (i.[PurchasePrice] * i.[ShareCount])
				+ (@SalePrice * i.[ShareCount])
	FROM Inserted i 
	WHERE [dbo].[Accounts].[AccountID] = i.[AccountID] 
END 

GO
ALTER TABLE [dbo].[Trades] ENABLE TRIGGER [TradesInsert]
GO
/****** Object:  Trigger [dbo].[TradesUpdate]    Script Date: 7/12/2020 6:48:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TradesUpdate] ON [dbo].[Trades] 
FOR UPDATE 
AS

/*
on update reverse the effects on account cash of existing trade and apply the new effects as if a fresh insert 
the only update from app should be to add SalePrice and Saledatetime but other sources might make changes to prices, accounts or symbols 
*/

BEGIN 
	SET NOCOUNT ON
	DECLARE @SalePrice int 

	--reverse the effect of existing trade
	SELECT @SalePrice = isnull([SalePrice], 0) FROM Deleted
	UPDATE [dbo].[Accounts] 
		SET [Cash] = [Cash] 
				+ (d.[PurchasePrice] * d.[ShareCount])
				- (@SalePrice * d.[ShareCount])
	FROM Deleted d 
	WHERE [dbo].[Accounts].[AccountID] = d.[AccountID]  

	--apply the new trade values
	SELECT @SalePrice = isnull([SalePrice], 0) FROM Inserted
	UPDATE [dbo].[Accounts] 
		SET [Cash] = [Cash] 
				- (i.[PurchasePrice] * i.[ShareCount])
				+ (@SalePrice * i.[ShareCount])
	FROM Inserted i 
	WHERE [dbo].[Accounts].[AccountID] = i.[AccountID]  
END 

GO
ALTER TABLE [dbo].[Trades] ENABLE TRIGGER [TradesUpdate]
GO
