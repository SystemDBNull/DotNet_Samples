﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SampleASP_20200703.Models;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace SampleASP_20200703.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home

        List<TradeModel> lstTrades = new List<TradeModel>();

        public ActionResult Index()
        {
            //return View();
            //lstTrades = new List<TradeModel>();
            DataTable tradesTable = QueryTrades(true, null, null, null); 

            for (int i = 0; i < tradesTable.Rows.Count; i++)
            {
                TradeModel trade = new TradeModel(tradesTable.Rows[i]);
                lstTrades.Add(trade); 
            }

            return View(lstTrades);
        }

        //Actions for Delete View 
        [HttpGet]
        public ActionResult Delete(string id)
        {
            //return View();
            DataTable tradesTable = QueryTrades(true, id, null, null);
            TradeModel deleteTrade = new TradeModel(); 

            for (int i = 0; i < tradesTable.Rows.Count; i++)
            {
                TradeModel trade = new TradeModel(tradesTable.Rows[i]);
                if (trade.TradeID == id)
                {
                    deleteTrade = trade;
                    break; 
                }
            }

            return View(deleteTrade);
        }

        /*Here I had two Actions for the same page, one for display and one for the update.
            in the example i was following the target object was passed to the Post but i couldn't get that to work. 
            i could pass the TradeID but then I had two methods with the same parameter signature. 
            found an example that included this ActionName attribute to get around that. */
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(string id)
        {
            DataTable tradesTable = QueryTrades(true, id, null, null);
            TradeModel deleteTrade = new TradeModel();

            for (int i = 0; i < tradesTable.Rows.Count; i++)
            {
                TradeModel trade = new TradeModel(tradesTable.Rows[i]);
                if (trade.TradeID == id)
                {
                    deleteTrade = trade;
                    break;
                }
            }

            deleteTrade.DeleteTrade(); 

            return RedirectToAction("Index");
        }

        //Actions for Complete View 
        [HttpGet]
        public ActionResult Complete(string id)
        {
            DataTable tradesTable = QueryTrades(true, id, null, null);
            TradeModel completeTrade = new TradeModel();

            for (int i = 0; i < tradesTable.Rows.Count; i++)
            {
                TradeModel trade = new TradeModel(tradesTable.Rows[i]);
                if (trade.TradeID == id)
                {
                    completeTrade = trade;
                    break;
                }
            }

            return View(completeTrade);
        }

        [HttpPost]
        public ActionResult Complete(string id, DateTime SaleDatetime, decimal SalePrice)
        {
            DataTable tradesTable = QueryTrades(true, id, null, null);
            TradeModel completeTrade = new TradeModel();

            for (int i = 0; i < tradesTable.Rows.Count; i++)
            {
                TradeModel trade = new TradeModel(tradesTable.Rows[i]);
                if (trade.TradeID == id)
                {
                    completeTrade = trade;
                    break;
                }
            }

            completeTrade.CompleteTrade(SaleDatetime, SalePrice); 

            return RedirectToAction("Index");
        }

        //Actions for AddTrade view 
        [HttpGet]
        public ActionResult AddTrade()
        {
            //running out of time so I'm pretty much copying code from a tutorial to populate my dropdowns 
            //i'll revisit this later to refine, add error handling 
            var accountList = new List<AccountListTable>();
            var symbolList = new List<SymbolListTable>();

            using (SqlConnection c = new SqlConnection(ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand("SELECT AccountID, AccountDisplay FROM [dbo].[Accounts] ORDER BY AccountDisplay", c))
            {
                c.Open(); 
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        accountList.Add(new AccountListTable
                        {
                            Key = rdr[0].ToString(),
                            Display = rdr[1].ToString()
                        });
                    }
                }
                c.Close(); 
            }

            using (SqlConnection c = new SqlConnection(ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString))
            using (SqlCommand cmd = new SqlCommand("SELECT SymbolID, SymbolDisplay FROM [dbo].[Symbols] ORDER BY SymbolDisplay", c))
            {
                c.Open();
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        symbolList.Add(new SymbolListTable
                        {
                            Key = rdr[0].ToString(),
                            Display = rdr[1].ToString()
                        });
                    }
                }
                c.Close();
            }

            var model = new TradeModel();
            model.AccountList = new SelectList(accountList, "Key", "Display");
            model.SymbolList = new SelectList(symbolList, "Key", "Display");

            return View(model);
        }

        //Actions for AddTrade view 
        [HttpPost]
        public ActionResult AddTrade(string AccountList, string SymbolList, int ShareCount, DateTime PurchaseDatetime, decimal PurchasePrice)
        {
            TradeModel createTrade = new TradeModel();

            createTrade.AccountID = AccountList;
            createTrade.SymbolID = SymbolList;
            createTrade.ShareCount = ShareCount;
            createTrade.PurchaseDatetime = PurchaseDatetime;
            createTrade.PurchasePrice = PurchasePrice;
            
            createTrade.CreateTrade();
            
            return RedirectToAction("Index");
        }

        //stub action for view remaining to be built 
        public ActionResult SymbolMaint()
        {
            return View(); 
        }

        //stub action for view remaining to be built 
        public ActionResult AccountMaint()
        {
            return View();
        }

        //database call to fetch denormalized records for populating the TradeModel objects 
        public DataTable QueryTrades(bool showAll, string TradeID, string accountId, string SymbolID)
        {
            DataTable tradesTable = new DataTable();
            string strConn = ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString;

            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                SqlCommand sqlCmd = new SqlCommand("PR_TradesReport", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add(new SqlParameter("@ShowAll", SqlDbType.Bit));
                sqlCmd.Parameters["@ShowAll"].Value = showAll;
                sqlCmd.Parameters.Add(new SqlParameter("@TradeID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TradeID"].Value = TradeID;
                sqlCmd.Parameters.Add(new SqlParameter("@AccountID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@AccountID"].Value = accountId;
                sqlCmd.Parameters.Add(new SqlParameter("@SymbolID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@SymbolID"].Value = SymbolID;
                SqlDataAdapter sqlAdapt = new SqlDataAdapter(sqlCmd);

                try
                {
                    sqlAdapt.Fill(tradesTable);
                }
                catch (Exception ex)
                {
                    //figure out best way to display this 
                    //until then just break execution 
                    throw (ex);
                }
            }

            return tradesTable;
        }



    }
}