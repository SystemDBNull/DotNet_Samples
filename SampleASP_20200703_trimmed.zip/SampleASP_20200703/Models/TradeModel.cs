﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc; 
using System.Web.Mvc.Html;
using System.Configuration;
using System.Data.SqlClient;

namespace SampleASP_20200703.Models
{
    public class TradeModel
    {
        /*TradeModel contains all the values relevent to a trade. 
            The class ought to have a property or properties that indicate it has been created in the db and is currently in or out of sync with the db record. 
            If TradeID is not null would suffice for the first state ... except for cash? For the second i think each editable property would have a setter method 
            that would mark it dirty then a db sync would unmark it. For now though the only updates available are for creating new records and completing open ones 
            and those two operations write to database in the same action that alters the object.
            To do: how to get objects and lists of objects to persist between page calls. */

        //Properties 
        /*As far as these properties some are required and one gets assigned at db insertion time 
            probably shouldn't be public, certainly not freely updateable 
            leave open for now but clean up later */
        public string TradeID { get; set; }
        public string Account { get; set; }
        public string AccountID { get; set; }
        public string Symbol { get; set; }
        public string SymbolID { get; set; }
        public int? ShareCount { get; set; }
        public DateTime? PurchaseDatetime { get; set; }
        public decimal? PurchasePrice { get; set; }
        public int? PurchaseValue { get; set; } //per PR_TradesReport: ShareCount * PurchasePrice 
        public DateTime? SaleDatetime { get; set; }
        public decimal? SalePrice { get; set; }
        public decimal? CurrentPrice { get; set; } //this comes from database field Symbols.SharePrice and may not be up to date 
        public int? CurrentValue { get; set; } //per PR_TradesReport: ShareCount * isnull(SalePrice, SharePrice) 
        public int? GainLoss { get; set; } //per PR_TradesReport: (SharePrice - PurchasePrice) * ShareCount
        public int? PercentGainLoss { get; set; } //per PR_TradesReport: ((SharePrice - PurchasePrice) * 100) / tr.PurchasePrice

        //need these for adding trades 
        public SelectList AccountList { get; set; }
        public SelectList SymbolList { get; set; }



        //Constructors
        public TradeModel()
        {
            //the example didn't have a constructor but i'm pretty sure there should be one 
        }

        public TradeModel(DataRow dr)
        {
            //if a trade is coming from the database that should have a constructor too 

            //this error handling needs refining  
            try
            {
                TradeID = dr["TradeID"].ToString();
                Account = dr["AccountDisplay"].ToString();
                AccountID = dr["AccountID"].ToString();
                Symbol = dr["SymbolDisplay"].ToString();
                SymbolID = dr["SymbolID"].ToString();
                ShareCount = Convert.ToInt32(dr["ShareCount"]);
                
                if (dr["PurchaseDatetime"] == DBNull.Value) { PurchaseDatetime = null; } 
                    else { PurchaseDatetime = Convert.ToDateTime(dr["PurchaseDatetime"]); }
                
                PurchasePrice = Convert.ToDecimal(dr["PurchasePrice"]);
                PurchaseValue = Convert.ToInt32(dr["ShareCount"]);

                if (dr["SaleDatetime"] == DBNull.Value) { SaleDatetime = null; }
                    else { SaleDatetime = Convert.ToDateTime(dr["SaleDatetime"]); }

                SalePrice = (decimal?)((dr["SaleDatetime"] == DBNull.Value) ? null : (dr["SalePrice"]));
                CurrentPrice = (decimal?)((dr["CurrentPrice"] == DBNull.Value) ? null : (dr["CurrentPrice"]));
                CurrentValue = (int?)((dr["CurrentValue"] == DBNull.Value) ? null : (dr["CurrentValue"]));
                GainLoss = (int?)((dr["Gain-Loss"] == DBNull.Value) ? null : (dr["Gain-Loss"]));
                PercentGainLoss = (int?)((dr["PercentGain-Loss"] == DBNull.Value) ? null : (dr["PercentGain-Loss"]));
            }
            catch (Exception ex)
            {
                //trashy but should get the job done while in progress 
                TradeID = null;
                Account = "Error: ";
                Symbol = ex.Message;
            }
        }

        //Methods 
        public bool DeleteTrade()
        {
            bool isSuccess = true;

            string strConn = ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString;

            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                SqlTransaction sqlTrans = null;
                SqlCommand sqlCmd = new SqlCommand("PR_TradesDelete", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add(new SqlParameter("@TradeID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TradeID"].Value = TradeID;

                try
                {
                    sqlConn.Open();
                    sqlTrans = sqlConn.BeginTransaction();
                    sqlCmd.Transaction = sqlTrans;
                    int i = sqlCmd.ExecuteNonQuery();
                    
                    //the return value should be number of rows affected. 
                    //should be one. if not then i assume something wrong and method should return false 
                    if (i != 1)
                    {
                        throw new Exception("Result from non-query is " + i + " and should be 1. Rolling back!"); 
                    }

                    sqlTrans.Commit();
                }
                catch (Exception ex)
                {
                    sqlTrans.Rollback();

                    isSuccess = false;
                    //figure out best way to display this 
                    //until then just break execution 
                    throw (ex);
                }
                finally
                {
                    sqlConn.Close();
                }
            }

            return isSuccess;

            //destroy the object or just let it drop off on the next refresh? 
        }

        public bool CompleteTrade(DateTime inDatetime, decimal inPrice)
        {
            bool isSuccess = true;

            SaleDatetime = inDatetime;
            SalePrice = inPrice;

            string strConn = ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString;

            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                SqlTransaction sqlTrans = null;
                SqlCommand sqlCmd = new SqlCommand("PR_TradesUpdate", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add(new SqlParameter("@TradeID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TradeID"].Value = TradeID;

                sqlCmd.Parameters.Add(new SqlParameter("@SaleDatetime", SqlDbType.DateTime));
                sqlCmd.Parameters["@SaleDatetime"].Value = SaleDatetime;

                sqlCmd.Parameters.Add(new SqlParameter("@SalePrice", SqlDbType.Decimal));
                sqlCmd.Parameters["@SalePrice"].Value = SalePrice;
                
                try
                {
                    sqlConn.Open();
                    sqlTrans = sqlConn.BeginTransaction();
                    sqlCmd.Transaction = sqlTrans; 
                    int i = sqlCmd.ExecuteNonQuery();
                    
                    //the return value should be number of rows affected. 
                    //should be one. if not then i assume something wrong and method should return false 
                    if (i != 1)
                    {
                        throw new Exception("Result from non-query is " + i + " and should be 1. Rolling back!");
                    }

                    sqlTrans.Commit();
                }
                catch (Exception ex)
                {
                    sqlTrans.Rollback(); 

                    isSuccess = false; 
                    //figure out best way to display this 
                    //until then just break execution 
                    throw (ex);
                }
                finally
                {
                    sqlConn.Close();
                }
            }

            return isSuccess;
        }

        public bool CreateTrade()
        {
            bool isSuccess = true;

            if (TradeID != null
                || AccountID == null || AccountID == string.Empty  
                || SymbolID == null || SymbolID == string.Empty
                || ShareCount == null
                || PurchaseDatetime == null
                || PurchasePrice == null) //verify we have the data needed for new trade record 
            {
                isSuccess = false; 
            }
            else
            {
                string strConn = ConfigurationManager.ConnectionStrings["TradesDB"].ConnectionString;

                using (SqlConnection sqlConn = new SqlConnection(strConn))
                {
                    SqlTransaction sqlTrans = null;
                    SqlCommand sqlCmd = new SqlCommand("PR_TradesInsert", sqlConn);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    
                    sqlCmd.Parameters.Add(new SqlParameter("@AccountID", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@AccountID"].Value = AccountID;
                    
                    sqlCmd.Parameters.Add(new SqlParameter("@SymbolID", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@SymbolID"].Value = SymbolID;

                    sqlCmd.Parameters.Add(new SqlParameter("@ShareCount", SqlDbType.Int));
                    sqlCmd.Parameters["@ShareCount"].Value = ShareCount;

                    sqlCmd.Parameters.Add(new SqlParameter("@PurchaseDatetime", SqlDbType.DateTime));    
                    sqlCmd.Parameters["@PurchaseDatetime"].Value = PurchaseDatetime;                    
                    
                    sqlCmd.Parameters.Add(new SqlParameter("@PurchasePrice", SqlDbType.Decimal));
                    sqlCmd.Parameters["@PurchasePrice"].Value = PurchasePrice;

                    try
                    {
                        sqlConn.Open();
                        sqlTrans = sqlConn.BeginTransaction();
                        sqlCmd.Transaction = sqlTrans;
                        int i = sqlCmd.ExecuteNonQuery();

                        //the return value should be number of rows affected. 
                        //should be one. if not then i assume something wrong and method should return false 
                        if (i != 1)
                        {
                            throw new Exception("Result from non-query is " + i + " and should be 1. Rolling back!");
                        }

                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();

                        isSuccess = false;
                        //figure out best way to display this 
                        //until then just break execution 
                        throw (ex);
                    }
                    finally
                    {
                        sqlConn.Close();
                    }
                }
            }

            return isSuccess;
        }
    }

    //additional classes. helpers in the creation of SelectList properties. include in same file for convenience 
    public class AccountListTable
    {
        public string Key { get; set; }
        public string Display { get; set; }
    }

    public class SymbolListTable
    {
        public string Key { get; set; }
        public string Display { get; set; }
    }
}