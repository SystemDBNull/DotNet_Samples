USE [Sample]
GO

/****** Object:  Table [dbo].[Level1]    Script Date: 05/15/2012 21:56:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Level1](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[Label] [nvarchar](255) NOT NULL,
	[IsSerialized] [bit] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Level1] ADD  CONSTRAINT [DF_Level1_CreateDate]  DEFAULT (getdate()) FOR [CreateDate]
GO

ALTER TABLE [dbo].[Level1] ADD  CONSTRAINT [DF_Level1_IsActive]  DEFAULT ((0)) FOR [IsSerialized]
GO

**************

USE [Sample]
GO

/****** Object:  Table [dbo].[Level2]    Script Date: 05/15/2012 21:56:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Level2](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Level1ID] [int] NOT NULL,
	[Label] [nvarchar](255) NOT NULL
) ON [PRIMARY]

GO

********************

USE [Sample]
GO

/****** Object:  Table [dbo].[Level3]    Script Date: 05/15/2012 21:57:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Level3](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Level2ID] [int] NOT NULL,
	[Label] [nvarchar](255) NOT NULL
) ON [PRIMARY]

GO

