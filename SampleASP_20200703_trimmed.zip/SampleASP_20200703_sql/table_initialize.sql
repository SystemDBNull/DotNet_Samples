

USE TradesDB; 

/*
DELETE FROM [dbo].[Trades]
DELETE FROM [dbo].[Symbols]
DELETE FROM [dbo].[Accounts]

--TRUNCATE TABLE [dbo].[Trades]
--TRUNCATE TABLE [dbo].[Symbols]
--TRUNCATE TABLE [dbo].[Accounts]

*/

/*
INSERT INTO [dbo].[Accounts] ( [AccountDisplay] , [Cash] ) 
VALUES ('Dennis Moore', 10000.00)  
	, ('I-Trade', 10000.00)  
	, ('European Century', 10000.00)  
--select * from [dbo].[Accounts]

INSERT INTO [dbo].[Symbols]( [SymbolDisplay] , [SharePrice] ) 
VALUES ('AAPL', 364.11)  
	, ('GOOG', 1464.70)  
	, ('TSLA', 1208.66)  
--select * from [dbo].[Symbols]

*/


/*
DECLARE @DennisMoore uniqueidentifier, @EuropeanCentury uniqueidentifier, @ITrade uniqueidentifier 
	, @AAPL uniqueidentifier, @GOOG uniqueidentifier, @TSLA uniqueidentifier 

SELECT @DennisMoore = CASE WHEN AccountDisplay = 'Dennis Moore' THEN AccountID ELSE @DennisMoore END 
	, @EuropeanCentury = CASE WHEN AccountDisplay = 'European Century' THEN AccountID ELSE @EuropeanCentury END 
	, @ITrade = CASE WHEN AccountDisplay = 'I-Trade' THEN AccountID ELSE @ITrade END 
FROM [dbo].[Accounts]

SELECT @AAPL = CASE WHEN SymbolDisplay = 'AAPL' THEN SymbolID ELSE @AAPL END 
	, @GOOG = CASE WHEN SymbolDisplay = 'GOOG' THEN SymbolID ELSE @GOOG END 
	, @TSLA = CASE WHEN SymbolDisplay = 'TSLA' THEN SymbolID ELSE @TSLA END 
FROM [dbo].[Symbols]

SELECT @DennisMoore , @EuropeanCentury , @ITrade  
	, @AAPL , @GOOG , @TSLA  


EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @DennisMoore
		, @SymbolID = @AAPL
		, @ShareCount = 1
		, @PurchaseDatetime = '2020-07-01 10:15:00.000'
		, @PurchasePrice = 300.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @DennisMoore
		, @SymbolID = @GOOG
		, @ShareCount = 2
		, @PurchaseDatetime = '2020-07-02 11:16:00.000'
		, @PurchasePrice = 1100.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @DennisMoore
		, @SymbolID = @TSLA
		, @ShareCount = 3
		, @PurchaseDatetime = '2020-07-03 12:24:00.000'
		, @PurchasePrice = 800.00


		/***/
EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @EuropeanCentury
		, @SymbolID = @AAPL
		, @ShareCount = 3
		, @PurchaseDatetime = '2020-07-02 10:03:00.000'
		, @PurchasePrice = 300.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @EuropeanCentury
		, @SymbolID = @GOOG
		, @ShareCount = 1
		, @PurchaseDatetime = '2020-07-04 11:07:00.000'
		, @PurchasePrice = 1100.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @EuropeanCentury
		, @SymbolID = @TSLA
		, @ShareCount = 2
		, @PurchaseDatetime = '2020-07-04 12:25:00.000'
		, @PurchasePrice = 800.00


		/***/
EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @ITrade
		, @SymbolID = @AAPL
		, @ShareCount = 2
		, @PurchaseDatetime = '2020-07-03 10:01:00.000'
		, @PurchasePrice = 300.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @ITrade
		, @SymbolID = @GOOG
		, @ShareCount = 3
		, @PurchaseDatetime = '2020-07-04 11:59:00.000'
		, @PurchasePrice = 1100.00

EXEC TradesDB.dbo.PR_TradesInsert 
		@AccountID = @ITrade
		, @SymbolID = @TSLA
		, @ShareCount = 1
		, @PurchaseDatetime = '2020-07-05 12:30:00.000'
		, @PurchasePrice = 800.00





*/

